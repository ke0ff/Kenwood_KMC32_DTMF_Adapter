/********************************************************************
 ************ COPYRIGHT (c) 2025 by ke0ff, Taylor, TX   *************
 *
 *  File name: main.c
 *
 *  Module:    Control
 *
 *  Summary:   This is keypad to DTMF generator for the ATTiny3217
 *
 *******************************************************************/

/********************************************************************
 * Created: 09/26/25
 * Author : joe.haas
 * Executes the keypad to DTMF gen.
 *
 * V1.1 SW Revnotes	10/26/25
 *	UP/DN debug complete.
 * V1.0 SW Revnotes	10/10/25
 *	Initial debug complete for keypad->dtmf
 *	Added code to support /PTT input and UP/DN outputs.  If PTT pressed,
 *		DTMF tones are generated when keys are pressed.  If PTT released,
 *		pressing "UP" or "DN" will ground the corresponding output until
 *		the key is released.
 * V0.0 SW Revnotes	09/26/25
 *	Initial project creation.
 *
 * ==================================================================
 * FFLASH Reset Controller Uses USART, GPIO, and Timer0B
 *
 * Timer0B is for application timers and DDS code (runs at 16 KHz rate)
 * DAC: output to generate tones (TONE)  DDS code is in driver_isr.c (TCB0_INT_vect)
 * USART is for capturing debug escape sequence commands (future provision for
 *		key-code commands using HM-133 adapter syntax).
 * NVMCTRL <not used>
 * GPIO:
 *			PA0 - n/u (UPDI)
 *			PA1 - ROW0		; input
 *			PA2 - ROW1		; input
 *			PA3 - ROW2		; input
 *			PA4 - ROW3		; input
 *			PA5 - spare		; input
 *			PA6 - TONE		; output
 *			PA7 - MMUTE		; output
 *
 *			PB0 - spare		; input
 *			PB1 - spare		; input
 *			PB2 - TXD		; output - dbug UART output to host
 *			PB3 - RXD		; input - captures debug UART cmds from host
 *			PB4 - spare		; input
 *			PB5 - DN		; input - DN output
 *			PB6 - UP		; input - UP output
 *			PB7 - spare		; input
 *
 *			PC0 - COL0		; output
 *			PC1 - COL1		; output
 *			PC2 - COL2		; output
 *			PC3 - COL3		; output
 *			PC4 - spare		; output
 *			PC5 - PTT		; input - /PTT input
 *
 *		GPIO: Standard 4x4 matrix scan logic to capture keypress (ROW/COL)
 *		GPIO: MMUTE to control mic mute
 *
 *		UART is optional debug port
 *
 *	!!! NEED TO REMEMBER THE FUSES !!! Wasted a lot of time on this chasing fuse ghosts left over from Artemis effort.
 *
 *	Key scan:
 *	Scan through columns to detect keypress(es) at rows.  At the end of each cycle, set all COL = low, if
 *	more than 1 button pressed, set test tone. COL outputs are either low or high-z (no pullup).
 *
 *	All functions working.  Timer ISR, UART ISR, and DAC are working.
 *	DTMF tone arrays are in-place.
 *	keypad scanning on COL[3:0] to capture keypresses.
 *	2-Key in one col capture is complete.  if two rows pressed, set a 1KHz tone.
 *
 *********************************************************************/

#include <atmel_start.h>
#include "usart_basic.h"
#include "main.h"
#include "driver_init.h"

//==================================================
// local Fn declarations


//==================================================
//#define DBUG

#define TSTF	4096	// 1KHz test tone
#define sleep()  __asm__ __volatile__ ("sleep" ::: "memory")
#define MS1			(16000/1000)
#define	KEY_SCAN	(MS1*10)		// 10ms scan rate
#define	MUT_DLY		(MS1*1000)		// 1 sec mute delay
#define	PTTMASK	0x20
#define UP_MASK	0x40
#define DN_MASK	0x20
#define ROW0	0x02				// ROW is active low.  When a key is pressed, a low from a COL output
#define ROW1	0x04				//	triggers capture when the corresponding ROW input is low.
#define ROW2	0x08
#define ROW3	0x10
#define COL0	0x02				// COL is active low with DIR port used to connect a col to the matrix
#define COL1	0x04
#define COL2	0x08
#define COL3	0x01

#define	VERSION	"\nKeyDTMF v1.1,Copyright (c) 10/26/2025 ke0ff, A.R.R.\n"

// Per DDS Appnote (NXP AN1771):
//		Fgen = (Fs * delta)/N
//
//	Fgen is in Hz, Fs is sample freq in Hz, N is the effective length of the sin() lookup table, delta = fractiaonal accumulator value (sets the tone freq).
//	Here, the radix for delta is between the high and low bytes of the 16b value.  The decimal value is calculated from the 16b binary DREG from delta = DREG/256:
//		Fgen = Fs * (DREG/256)/N	{this equation changes if the location of the radix is moved, e.g., the length of the sin() table is changed}
//
// Rearrange to calculate DREG:
//		DREG = Fgen * N * 256 / Fs
//		     = Fgen * 65536 / 16000
//
// DREG is the 16b binary delta value that corresponds to the desired frequency
// Fgen is the desired frequency (Hz)
// N is the sin() table length (256, here)
// Fs is the sample frequency (Hz)
//
// Fstep is the minimum frequency step that can ve produced with a given set of constraints.  It is calculated by setting DREG = 1:
//		Fstep = Fs * (DREG/256)/N
//			  = 16000 * 1/65536 = 0.244141 Hz
//
// At the maximum frequency, the maximum error (assuming all other errors are zero) will be +/-(Fstep/2).  Thus, the max error in percent will be:
//		1 - (Fmin/(Fmin+(Fstep/2)) = .026%
//
// At 259 ppm, the base accuracy of the ATTINY will likely charge a greater toll on the overall error budget.  Per ITU specifications, frequency tolerance shall be
//	within +/- 1.5% (1500 ppm) of the desired frequency.
// Twist: high group amplitudes shall be within -8 to +4 dB relative to the low-group amplitudes.  Other in-band noise must be <= -55 dBm.  Assuming -2dBm as a typical
//	level for the high or low group, this puts the noise limit (quiet) at around -57 dBc (safe limit is around -65 dBc).
//
//							  697   770      852            941
uint16_t	delf_row[] = { 0, 2855, 3154, 0, 3490, 0, 0, 0, 3854, 				// trade FLASH for code speed.  0 values are unused row combos used for 1-tone generation.
						   0, 0, 0, 0, 0, 0, 0 };

//						      1209  1336     1477           1633
uint16_t	delf_col[] = { 0, 4952, 5472, 0, 6050, 0, 0, 0, 6689,				// col tones
						   0, 0, 0, 0, 0, 0, 0 };

//-----------------------------------------------------------------------------
// main() application loop
//-----------------------------------------------------------------------------
int main(void)
{
#ifdef DBUG
	char cbuf[10];						// usart cmd buff
	volatile uint8_t	c;				// table index, col
#endif
	volatile uint8_t	pttreg;			// ptt capture reg
//	volatile uint8_t	pttedg;			// ptt edge reg
	volatile uint8_t	r;				// table index, row
	volatile uint8_t	row;			// row input
	volatile uint8_t	srow = 0xff;	// row input (2nd stab)
	volatile uint8_t	col = 1;		// col DIR output
	volatile uint8_t	scol;			// col read
	volatile uint8_t	rcol = 0xff;	// col read
	volatile uint8_t	tonon = 0;		// tone on flag (local)
	volatile uint8_t	keyskp = 0;		// keypad change flag
	volatile uint16_t	ii;				// temp row tone value
	volatile uint16_t	jj;				// temp col tone value

#define ROW_MASK	(0x0f<<1)			// bit mask for rows
#define COL_MASK	(0x0f)				// bit mask for cols.
#define ROW_IDX		(1)					// shift count to align row as index

	// Initializes MCU, drivers and middleware
	atmel_start_init();										// init MCU
	sei();													// enable global interrupt flag
	initdds();												// perform IPL init of DDS Fn
	gotmsg(1);												// clear message counter
	wait_T(20);
	chk_tmr0(TIMER_CLEAR);									// init timer
	putsu(VERSION);											// display SW vers
//	pttedg = 0xff;											// force 1st edge
#ifdef DBUG
	putsu("DBUG\n");						// dbug
#endif
	wait_T(20);
	PORTC.OUT = 0;											// COL (portc) pins = 0 when set to output
															// COL outs are active low with DIR port used to enable 1 column at a time
	// DTMF application code
	while (1) {
		sleep();											// WAI (or WFI, depending on you preferred flavor of assembly)
		wait_T(KEY_SCAN);								// let I/O settle..
		// capture PTT
		pttreg = (~VPORTC.IN) & PTTMASK;
		row = VPORTA.IN & ROW_MASK;							// ..then grab row/col
		rcol = ~VPORTC.IN & COL_MASK;
		if((row != srow) || (rcol != scol)){
			keyskp = 1;										// if a change to the keypress, turn off tone
		}
		if(tonon){											// if tones are on, look for key release
//			row = VPORTA.IN & ROW_MASK;
			if(keyskp || !pttreg){
				tonon = 0;									// no key no ptt, turn off tone
				set_tone_on(tonon);
				srow = ROW_MASK;							// clear prev keypress
				scol = 0;
#ifdef DBUG
				putsu("off\n");				// dbug
#endif
			}else{
				mut_tmr(MUT_DLY);							// reset mute delay				
			}
		}else{												// tones are off, look for keypress...
			keyskp = 0;
//			wait_T(KEY_SCAN);								// let I/O settle..
			// scan key matrix
			set_tone_on(tonon);								// process mute off when mute timer expires
			if(row == ROW_MASK){
				// no keypress, next col..
				VPORTC.DIR = col;
				col <<= 1;									// set new col
				if(col>8) col = 1;							// rollover col	
				UP_set_level(0);							// No presses, clear outputs
				DN_set_level(0);
				srow = ROW_MASK;							// clear prev keypress
				scol = 0;
			}else{
				// key pressed
				wait_T(KEY_SCAN);							// settling time
				srow = VPORTA.IN & ROW_MASK;				// get and mask row inputs
				if(row == srow){							// same key pressed
					if(!pttreg){							// PTT released...
						if(row == ((~ROW3) & ROW_MASK)){					// process up/dn presses to outputs
							if(col == COL0) DN_set_level(1);
							if(col == COL2) UP_set_level(1);
						}
					}else{									// PTT pressed
						UP_set_level(0);					// No UP/DN if tone is on
						DN_set_level(0);
						// pressed key, set tone & toneon
						r = (~row & ROW_MASK) >> ROW_IDX;	// invert & align row to bit 0 to create index
						tonon = 1;							// turn on tone flag
						ii = delf_row[r];					// capture row/col tones
						scol = ~VPORTC.IN & COL_MASK;
						jj = delf_col[scol];
//						if(jj == 0) ii = TSTF;
						set_tone(ii, 0);					// set row/col tones
						set_tone(jj, 1);
						mut_tmr(MUT_DLY);					// set mute delay (must do before tone=on)
						set_tone_on(tonon);					// turn on DDS tone, mute mic
					}
#ifdef DBUG
					puthex((r<<4)|col);		// dbug
					putsu("\n");			// dbug
#endif
				}
			}
		}
#ifdef DBUG
		// USART (dbug)
		if(gotmsg(0)){							// capture tone set commands
			gets(cbuf);							// "rc" are ASCII numbers for each nybble.  Any other character turns off tone
			r = cbuf[0];						// "rc" sets index into frequency tables.  Valid digits are 1, 2, 4, and 8.  0 for row sets test tone
			c = cbuf[1];
			r -= '0';
			c -= '0';
			if(r>=0 && c>=0 && r<4 && c<4){
				set_tone(delf_row[r], 0);
				set_tone(delf_col[c], 1);
				set_tone_on(1);
				putsu("on\n");
			}else{
				set_tone_on(0);
				putsu("off\n");
			}
		}
#endif
	}
}


// EOF main.c