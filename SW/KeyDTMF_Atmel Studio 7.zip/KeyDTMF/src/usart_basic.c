/**
 * \file
 *
 * \brief USART basic driver.
 *
 (c) 2020 Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms,you may use this software and
    any derivatives exclusively with Microchip products.It is your responsibility
    to comply with third party license terms applicable to your use of third party
    software (including open source software) that may accompany Microchip software.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
    WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
    PARTICULAR PURPOSE.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
    BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
    FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
    ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
    THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 */

/**
 * \defgroup doc_driver_usart_basic USART Basic
 * \ingroup doc_driver_usart
 *
 * \section doc_driver_usart_basic_rev Revision History
 * - v0.0.0.1 Initial Commit
 *
 *@{
 */
#include <compiler.h>
#include <clock_config.h>
#include <usart_basic.h>
#include <atomic.h>
#include "main.h"
#include "driver_init.h"

static char	ubuf[UBUF_MAX];			// uart rx buffer
volatile static uint8_t	hptr;					// head pointer
volatile static uint8_t	tptr;					// tail pointer
volatile static uint8_t	esc_active;				// escape window open
volatile static uint8_t	ucmd;					// valid cmd
volatile static uint8_t	stat;					// valid cmd
volatile static uint8_t	msgcnt;					// msg counter
//volatile static char	utbuf[UTBUF_MAX];			// uart rx buffer
//volatile static uint8_t	htptr;					// head pointer

#define CNTLY	25								// UART escape character
#define ESC_DLY	3000							// escape pre-quiet/entry window (ms)
#define DLY0	0xffff							// zero timer
#define	EOL		'\r'
#define RXD_ERR	0x01
/**
 * \brief Initialize USART interface
 * If module is configured to disabled state, the clock to the USART is disabled
 * if this is supported by the device's clock system.
 *
 * \return Initialization status.
 * \retval 0 the USART init was successful
 * \retval 1 the USART init was not successful
 */
int8_t USART_0_init(uint16_t baudr)
{
	USART0.CTRLB &= ~(USART_RXEN_bm | USART_TXEN_bm);		// disable USART

	USART0.BAUD = (uint16_t)USART0_BAUD_RATE(baudr);			// set baud rate register

	 USART0.CTRLA = 0 << USART_ABEIE_bp						// Auto-baud Error Interrupt Enable: disabled
			 | 0 << USART_DREIE_bp							// Data Register Empty Interrupt Enable: disabled
			 | 0 << USART_LBME_bp							// Loop-back Mode Enable: disabled
			 | USART_RS485_OFF_gc							// RS485 Mode disabled
			 | 1 << USART_RXCIE_bp							// Receive Complete Interrupt Enable: enabled
			 | 0 << USART_RXSIE_bp							// Receiver Start Frame Interrupt Enable: disabled
			 | 0 << USART_TXCIE_bp;							// Transmit Complete Interrupt Enable: disabled

	 USART0.CTRLC = USART_CMODE_ASYNCHRONOUS_gc				// Asynchronous Mode
			 | USART_CHSIZE_8BIT_gc							// Character size: 8 bit
			 | USART_PMODE_DISABLED_gc						// No Parity
			 | USART_SBMODE_1BIT_gc;						// 1 stop bit

//	USART0.DBGCTRL = 0 << USART_DBGRUN_bp;					// Debug Run: disabled

//	USART0.EVCTRL = 0 << USART_IREI_bp;						// IrDA Event Input Enable: disabled

//	USART0.RXPLCTRL = 0x0 << USART_RXPL_gp;					// Receiver Pulse Length: 0x0

//	USART0.TXPLCTRL = 0x0 << USART_TXPL_gp;					// Transmit pulse length: 0x0


	USART0.CTRLB = 0 << USART_MPCM_bp						// Multi-processor Communication Mode: disabled
			| 0 << USART_ODME_bp							// Open Drain Mode Enable: disabled
			| 1 << USART_RXEN_bp							// Receiver Enable: enabled
			| USART_RXMODE_NORMAL_gc						// Normal mode
			| 0 << USART_SFDEN_bp							// Start Frame Detection Enable: disabled
			| 1 << USART_TXEN_bp;							// Transmitter Enable: enabled

	// init ISR registers
	hptr = 0;
	tptr = 0;
	esc_active = 0;
	ucmd = 0;
//	chk_tmr0(DLY0);
	return 0;
}

/**
 * \brief Enable RX and TX in USART_0
 * 1. If supported by the clock system, enables the clock to the USART
 * 2. Enables the USART module by setting the RX and TX enable-bits in the USART control register
 *
 * \return Nothing
 */
void USART_0_enable()
{
	USART0.CTRLB |= USART_RXEN_bm | USART_TXEN_bm;
}

/**
 * \brief Enable RX in USART_0
 * 1. If supported by the clock system, enables the clock to the USART
 * 2. Enables the USART module by setting the RX enable-bit in the USART control register
 *
 * \return Nothing
 */
void USART_0_enable_rx()
{
	USART0.CTRLB |= USART_RXEN_bm;
}

/**
 * \brief Enable TX in USART_0
 * 1. If supported by the clock system, enables the clock to the USART
 * 2. Enables the USART module by setting the TX enable-bit in the USART control register
 *
 * \return Nothing
 */
void USART_0_enable_tx()
{
	USART0.CTRLB |= USART_TXEN_bm;
}

/**
 * \brief Disable USART_0
 * 1. Disables the USART module by clearing the enable-bit(s) in the USART control register
 * 2. If supported by the clock system, disables the clock to the USART
 *
 * \return Nothing
 */
void USART_0_disable()
{
	USART0.CTRLB &= ~(USART_RXEN_bm | USART_TXEN_bm);
}

/**
 * \brief Get recieved data from USART_0
 *
 * \return Data register from USART_0 module
 */
uint8_t USART_0_get_data()
{
	return USART0.RXDATAL;
}

/**
 * \brief Check if the usart can accept data to be transmitted
 *
 * \return The status of USART TX data ready check
 * \retval false The USART can not receive data to be transmitted
 * \retval true The USART can receive data to be transmitted
 */
bool USART_0_is_tx_ready()
{
	return (USART0.STATUS & USART_DREIF_bm);
}

/**
 * \brief Check if the USART has received data
 *
 * \return The status of USART RX data ready check
 * \retval true The USART has received data
 * \retval false The USART has not received data
 */
bool USART_0_is_rx_ready()
{
	return (USART0.STATUS & USART_RXCIF_bm);
}

/**
 * \brief Check if USART_0 data is transmitted
 *
 * \return Receiver ready status
 * \retval true  Data is not completely shifted out of the shift register
 * \retval false Data completely shifted out if the USART shift register
 */
bool USART_0_is_tx_busy()
{
	return (!(USART0.STATUS & USART_TXCIF_bm));
}

/**
 * \brief Read one character from USART_0
 *
 * Function will block if a character is not available.
 *
 * \return Data read from the USART_0 module
 */
uint8_t USART_0_read()
{
	while (!(USART0.STATUS & USART_RXCIF_bm))
		;
	return USART0.RXDATAL;
}

/**
 * \brief Write one character to USART_0
 *
 * Function will block until a character can be accepted.
 *
 * \param[in] data The character to write to the USART
 *
 * \return Nothing
 */
void USART_0_write(const uint8_t data)
{
	while (!(USART0.STATUS & USART_DREIF_bm));
	USART0.TXDATAL = data;
}

//-----------------------------------------------------------------------------
// getchr looks for chr @ rx buff.  If none, return '\0'
//	uses circular buffer ubuf[] which is filled in the USART interrupt
//-----------------------------------------------------------------------------
char getchr(void){

	char c = '\0';

	if(tptr != hptr){								// if head != tail,
		c = ubuf[tptr++];							// get chr from circ-buff and update tail ptr
		if(tptr >= UBUF_MAX){						// process tail wrap-around
			tptr = 0;
		}
	}
	return c;
}

//-----------------------------------------------------------------------------
// gotchr looks for chr in USART rx buf.  If none, return FALSE, else return TRUE
//	must pass the counter to the msg chr index (first chr = 0).
//-----------------------------------------------------------------------------
char gotchr(void){
	char c = FALSE;			// return val, default to "no chr"

    if(tptr != hptr){								// if (head != tail)..
    	c = TRUE;									// .. set chr ready to get flag
	}
	return c;
}

//-----------------------------------------------------------------------------
// gotmsg() returns true if msgcnt != 0.
//-----------------------------------------------------------------------------

char gotmsg(uint8_t clear_flag){
	char c = FALSE;			// return val, default to "no chr"

    if(clear_flag){
	   	msgcnt = 0;
   }
    if(msgcnt){
    	c = TRUE;
//    	msgcnt -= 1;
	}
	return c;
}

//-----------------------------------------------------------------------------
// gets() does gets from USART buffers
//	On entry, string (ptr) points to start of destination.  On exit, string points
//	to end of dest string + 1.
//-----------------------------------------------------------------------------
char* gets(char *string){
	char c = 0;

	while(gotchr() && (c != '\r')){					// ..and as long as there are chrs in rx1 buffer..
		c = getchr();
		*string++ = c;								// ..then, transfer rx1 buffer to string
	}
	*string = '\0';									// set end of string (point to frame status after placing the null)
	if(msgcnt) msgcnt--;
	return string;									// return pointer to (end of dest)
}

//-----------------------------------------------------------------------------
// getrptr() returns pointer to RX buffer
//-----------------------------------------------------------------------------
char* getrptr(void){

	return ubuf;									// return pointer to (end of dest)
}

//-----------------------------------------------------------------------------
// getstat() returns USART status byte. if param = TRUE, clear the flag after reading
//-----------------------------------------------------------------------------
uint8_t getstat(uint8_t clear_flag){
	volatile uint8_t c;			// return reg

	cli();
	// capture status value
    c = ucmd;
	// process clear status cmd
    if((clear_flag) && (ucmd)){						
    	ucmd = 0;
		esc_active = false;
    }
	sei();
	return c;
}

//*********************************************
// putsu() a local puts function for the UART
//	inserts <CR> with each newline.  Newline is NOT implicit.
//	Returns number of characters sent to the UART (including
//	any <CR> characters inserted).
//USART0.CTRLA &= ~(1 << USART_DREIE_bp);
int putsu(char* s){
	int i = 0;
	char* sp = s;

	while(*sp){
		if(*sp == '\n'){
			USART_0_write('\r');
			i++;
		}
		USART_0_write(*sp++);
		i++;
	}
	return i;
}

//*********************************************
// sputd() does an ascii hex-> dec and places output at s pointer.
//	if "z" is true, pad leading zeros with spaces, else left justify (no leading zero or space)
//	returns new string pointer
//
char* sputd(char *s, uint8_t z, uint8_t d){
	uint8_t i = d;
	uint8_t	huns = 0;
	uint8_t	tens;
	uint8_t	ones;

	if(i > 199){
		huns = 2;
		i -= 200;
	}else{
		if(i > 99){
			huns = 1;
			i -= 100;
		}
	}
	tens = i/10;
	ones = i%10;

	i = 0;							// leading zero suppress
	if(huns){
		*s++ = huns + '0';
		i = 1;
	}else{
		if(z) *s++ = ' ';
	}
	if(!i && (tens == 0)){
		if(z) *s++ = ' ';
	}else{
		*s++ = tens + '0';
		i = 1;
	}
	*s++ = ones + '0';
	*s = '\0';
	return s;
}

//*********************************************
// sputx() does an ascii hex-> hex and places output at s pointer.
//	returns new string pointer
//
char* sputx(char *s, uint8_t x){

	*s++ = hexasc(x>>4);
	*s++ = hexasc(x);
	*s = '\0';
	return s;
}

//*********************************************
// puthex() returns ascii char of low nybble of "x"
//
void puthex(uint8_t x){

	USART_0_write(hexasc(x>>4));
	USART_0_write(hexasc(x));
	return;
}

//*********************************************
// hexasc() returns ascii char of low nybble of "x"
//
char hexasc(uint8_t x){
	char	c;
	
	c = (x & 0x0f) + '0';
	if(c > '9') c += 'a' - '9' - 1;
	return c;
}
/////////////////////////////////////
// USART RXD ISR
// captures USART data to rolling buffer
//
ISR(USART0_RXC_vect)
{
	volatile char	c;		// temp char

	c = USART0.RXDATAL;
	if((c > ESC) || (c == EOL)){
		if(c == EOL){
			c = '\0';									// null-term lines
		}
		ubuf[hptr++] = c;								// feed the buffer
		if(hptr >= UBUF_MAX){
			hptr = 0;									// wrap buffer ptr
		}
		if(hptr == tptr){
			stat |= RXD_ERR;							// buffer overrun, set error
			msgcnt = 0;
		}
		if(c == '\0') msgcnt++;							// increment msg count if EOM (now a null in the datastream) is detected
	}
}


/////////////////////////////////////
// USART TXD ISR
//
/*
ISR(USART0_DRE_vect)
{
//	while (!(USART0.STATUS & USART_DREIF_bm))

	USART0.TXDATAL = utbuf[ttptr++];
	if(ttptr >= UTBUF_MAX) ttptr = 0;
	if(ttptr == htptr){ // turn off isr
		USART0.CTRLA &= ~(1 << USART_DREIE_bp);
			// 0 << USART_ABEIE_bp // Auto-baud Error Interrupt Enable: disabled
			// | 0 << USART_DREIE_bp // Data Register Empty Interrupt Enable: disabled
			// | 0 << USART_LBME_bp // Loop-back Mode Enable: disabled
			// | USART_RS485_OFF_gc // RS485 Mode disabled
			// | 0 << USART_RXCIE_bp // Receive Complete Interrupt Enable: disabled
			// | 0 << USART_RXSIE_bp // Receiver Start Frame Interrupt Enable: disabled
			// | 0 << USART_TXCIE_bp; // Transmit Complete Interrupt Enable: disabled
	}
}*/

// EOF usart_basic.c
